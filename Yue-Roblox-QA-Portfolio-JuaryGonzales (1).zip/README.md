# Yue — Roblox QA Portfolio

A personal portfolio website for Roblox quality assurance, bug reporting, functional testing, and gameplay testing.

- **Portfolio display name:** Yue
- **GitHub username:** [JuaryGonzales](https://github.com/JuaryGonzales)
- **Website repository:** `Yue-Roblox-QA-Portfolio`

## Publish with GitHub Pages

1. Sign in to GitHub as **JuaryGonzales**.
2. Create a public repository named `Yue-Roblox-QA-Portfolio`.
3. Upload `index.html` and `style.css` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait for GitHub Pages to publish your site.

Your expected website address will be:

`https://JuaryGonzales.github.io/Yue-Roblox-QA-Portfolio/`

Before publishing, replace sample game names and any placeholder project details in `index.html` with your real testing experience. Your public-facing name remains **Yue**; **JuaryGonzales** is used only for your GitHub account and links.
